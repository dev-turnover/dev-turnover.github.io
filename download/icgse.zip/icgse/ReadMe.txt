Below explains the columns of data files.
uid: unique user id
first_commit_date: the date developer made first commit
first_commit_year: the year developer made first commit
last_commit_date: the date developer made last commit
duration: the difference of first_commit_date and last_commit_date
leaver_mark_180: whether developer has left the project using the censoring days of 180
leaver_mark_30: whether developer has left the project using the censoring days of 30
leaver_mark_90: whether developer has left the project using the censoring days of 90
commit_times: number of total commits of the developer
largest_delta: the biggest difference between two consecutive commits
over_delta: the number of times when one commit was made more than 180 days after the last commit
repository_no: number of repositories the developer contributed to
repositories: a dictionary type field, standing for how many times the developer committed to each repository
action_types: a dictionary type field, standing for how many times the developer executes each action
action_A: how many times the developer add a file
action_D: how many times the developer delete a file
action_V: how many times the developer rename a file
action_M: how many times the developer modify a file
action_C: how many times the developer copy a file
action_A_level: action_A converted to percentage
action_D_level: action_D converted to percentage
action_V_level: action_V converted to percentage
action_M_level: action_M converted to percentage
action_C_level: action_C converted to percentage
action_main: the main action type
file_types: a dictionary type field, standing for how many times a developer touches each type of files
file_unknown: how many times the developer touches "unknown" files
file_devel-doc: how many times the developer touches "devel-doc" files
file_build: how many times the developer touches "build" files
file_code: how many times the developer touches "code" files
file_i18n: how many times the developer touches "i18n" files
file_documentation: how many times the developer touches "documentation" files
file_image: how many times the developer touches "image" files
file_ui: how many times the developer touches "ui" files
file_package: how many times the developer touches "package" files
file_unknown_level: file_unknown converted to percentage
file_devel-doc_level: file_devel-doc converted to percentage
file_build_level: file_build converted to percentage
file_code_level: file_code converted to percentage
file_i18n_level: file_i18n converted to percentage
file_documentation_level: file_documentation converted to percentage
file_image_level: file_image converted to percentage
file_ui_level: file_ui converted to percentage
file_package_level: file_package converted to percentage
file_type_main: the main file type
original_rate: rate of maintaining own files
original_level: original_rate converted to percentage
