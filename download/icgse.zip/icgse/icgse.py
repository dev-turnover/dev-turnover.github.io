import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter


def sa_first_commit_year(database, mark):
    """
    Survival analysis by first commit year
    Input:
      database - database name,
      mark - 'leaver_mark_30', 'leaver_mark_90' or 'leaver_mark_180', namely the censoring days of survival analysis
    """
    df = pd.read_csv('data/'+database+'.csv', sep=',')
    color_set = ['#F0A3FF', '#C20088', '#FF0010', '#FF5005', '#FFCC99', '#FFFF00', '#2BCE48', '#5EF1F2', '#0075DC',
                 '#003380', '#740AFF', '#C20088', '#8F7C00', '#191919']
    plt.figure(figsize=(8.4, 6))
    ax = plt.subplot(111)
    kmf = KaplanMeierFitter()
    color_index = 0
    index = 'first_commit_year'
    if database == 'openstack':
        init_year = 2008
        color_set = color_set[6:]
    elif database == 'cloudstack':
        init_year = 2010
        color_set = color_set[8:]
    elif database == 'glusterfs':
        init_year = 2009
        color_set = color_set[7:]
    elif database == 'xen':
        init_year = 2002
    elif database == 'wikimedia':
        init_year = 2003
        color_set = color_set[1:]

    for group in range(init_year, 2016):
        try:
            data = df[df[index] == group]
            kmf.fit(data['duration'], data[mark], label=str(group))
            kmf.survival_function_.plot(ax=ax, c=color_set[color_index])
        except:
            print database, group
        color_index += 1
    plt.xlabel('Days active in the project (censoring: '+mark.split('_')[-1]+' days)')
    plt.ylabel('Survival probability')
    plt.ylim([0, 1])

    plt.savefig('results/'+database+'_'+mark+'_'+index+'.pdf')
    plt.close()


def sa_main_action(database, mark):
    """
    Survival analysis by main action type
    Input:
      database - database name,
      mark - 'leaver_mark_30', 'leaver_mark_90' or 'leaver_mark_180', namely the censoring days of survival analysis
    """
    df = pd.read_csv('data/'+database+'.csv', sep=',')
    color_set = ['#1DC700', '#c91050']
    plt.figure(figsize=(7, 5))
    ax = plt.subplot(111)
    kmf = KaplanMeierFitter()
    color_index = 0
    index = 'action_main'
    groups = ['A', 'M']
    for group in groups:
        try:
            data = df[df[index] == group]
            kmf.fit(data['duration'], data[mark], label=str(group))
            kmf.survival_function_.plot(ax=ax, c=color_set[color_index])
        except:
            print group
        color_index += 1
    plt.xlabel('Days active in the project (censoring: '+mark.split('_')[-1]+' days)')
    plt.ylabel('Survival probability')
    plt.ylim([0, 1])
    plt.savefig('results/'+database+'_'+mark+'_'+index+'.pdf')
    plt.close()


def sa_own_files(database, mark):
    """
    Survival analysis by the rate of maintaining own files
    Input:
      database - database name,
      mark - 'leaver_mark_30', 'leaver_mark_90' or 'leaver_mark_180', namely the censoring days of survival analysis
    """
    df = pd.read_csv('data/'+database+'.csv', sep=',')
    color_set = ['#F21462', '#FBB100', '#FBEA66', '#94F96C', '#1DC700', '#01868D', '#79B0F9', '#1C19D6',
                 '#361281', '#808080', '#000000']
    plt.figure(figsize=(8.4, 6))
    ax = plt.subplot(111)
    kmf = KaplanMeierFitter()
    color_index = 0
    index = 'original_level'
    if database == 'redhat_glusterfs':
        color_set = ['#F21462', '#FBB100', '#FBEA66', '#94F96C', '#000000']
        groups = ['00-10%', '10-20%', '20-30%', '30-40%', '90-100%']
    else:
        groups = df.sort_values([index])[index].unique()
    for group in groups:
        try:
            data = df[df[index] == group]
            kmf.fit(data['duration'], data[mark], label=str(group))
            kmf.survival_function_.plot(ax=ax, c=color_set[color_index])
        except:
            print group
        color_index += 1
    plt.xlabel('Days active in the project (censoring: '+mark.split('_')[-1]+' days)')
    plt.ylabel('Survival probability')
    plt.ylim([0, 1])

    plt.savefig('results/'+database+'_'+mark+'_'+index+'.pdf')
    plt.close()


def sa_main_job(database, mark):
    """
    Survival analysis by the main job
    Input:
      database - database name,
      mark - 'leaver_mark_30', 'leaver_mark_90' or 'leaver_mark_180', namely the censoring days of survival analysis
    """
    df = pd.read_csv('data/'+database+'.csv', sep=',')
    color_set = ['#1DC700', '#c91050']
    plt.figure(figsize=(8.4, 6))
    ax = plt.subplot(111)
    kmf = KaplanMeierFitter()
    color_index = 0
    index = 'file_type_main'

    groups = ['code', 'documentation']
    for group in groups:
        try:
            data = df[df[index] == group]
            kmf.fit(data['duration'], data[mark], label=str(group))
            kmf.survival_function_.plot(ax=ax, c=color_set[color_index])
        except:
            print group
        color_index += 1
    plt.xlabel('Days active in the project (censoring: '+mark.split('_')[-1]+' days)')
    plt.ylabel('Survival probability')
    plt.ylim([0, 1])

    plt.savefig('results/'+database+'_'+mark+'_'+index+'.pdf')
    plt.close()


if __name__ == '__main__':
    database_list = ['openstack', 'cloudstack', 'glusterfs', 'xen', 'wikimedia']
    for database in database_list:
        for mark in ['leaver_mark_30', 'leaver_mark_90', 'leaver_mark_180']:
            sa_first_commit_year(database, mark)
            sa_own_files(database, mark)
            sa_main_action(database, mark)
            sa_main_job(database, mark)
